debug = True
if __name__ == '__main__':
    print(debug)